﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;

namespace WpfApplication1
{
    public class ItemTemplateSelector : DataTemplateSelector
    {
        public DataTemplate DefaultnDataTemplate { get; set; }
        public DataTemplate NoteDataTemplate { get; set; }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            if (null == item)
                return DefaultnDataTemplate;
            if (item.GetType() == typeof(WifiNetworkDto))
            {
                return NoteDataTemplate;
            }

            return DefaultnDataTemplate;
        }
    }
}
