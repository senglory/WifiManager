﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication1
{
    public class WifiNetworkDto
    {
        public string Name { get; set; }
        public string Bssid { get; set; }
        public string Password { get; set; }
        public string WifiType { get; set; }
        public bool IsBanned { get; set; }
        public bool IsInCSVList { get; set; }
    }

    public class NotifyUIBase : INotifyPropertyChanged
    {
        // Very minimal implementation of INotifyPropertyChanged matching msdn
        // Note that this is dependent on .net 4.5+ because of CallerMemberName
        public event PropertyChangedEventHandler PropertyChanged;
        public void RaisePropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

    public class MainWindowVM : NotifyUIBase
    {
        ObservableCollection<WifiNetworkDto> _allrecs = new ObservableCollection<WifiNetworkDto>();
        public ObservableCollection<WifiNetworkDto> AllRecords
        {
            get { return _allrecs; }
            set
            {
                _allrecs = value;
                _allrecsQuickSearch.Clear();
                foreach (var nw in _allrecs)
                {
                    _allrecsQuickSearch.Add(nw.Bssid, nw);
                }
                RaisePropertyChanged("AllRecords");
            }
        }

        Dictionary<string, WifiNetworkDto> _allrecsQuickSearch = new Dictionary<string, WifiNetworkDto>();
        public Dictionary<string, WifiNetworkDto> AllRecordsQuickSearch
        {
            get { return _allrecsQuickSearch; }
        }

        public WifiNetworkDto TheSelected { get; set; }


        public MainWindowVM(List<WifiNetworkDto> networks) {
            AllRecords = new ObservableCollection<WifiNetworkDto>(networks);
        }

        public void SortList()
        {
            AllRecords = new ObservableCollection<WifiNetworkDto>(AllRecords.OrderByDescending(nw => nw.IsInCSVList).OrderBy(nw => nw.IsBanned).OrderBy(nw => nw.Name));
        }
    }
}
