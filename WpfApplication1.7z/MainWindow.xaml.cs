﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using CommonFileTransferLibrary;
using System.IO.Compression;
using ICSharpCode.SharpZipLib;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Lzw;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.BZip2;
using ICSharpCode.SharpZipLib.GZip;
using SevenZip;
using Ionic.Zip;
using Ionic.Zlib;
using System.Xml.Xsl;
using System.Xml.Linq;
using System.Data.Odbc;

namespace WpfApplication1
{


    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindowVM TheVM { get; set; }


        class FileFromSFTP
        {
            public ThinFile FileOnSFTP;
            public string DownloadedAs;
            public string ExtractedXmlFileName;
            public string XsltOutputName;
            public bool Processed;
        }

        public MainWindow()
        {
            Trace.Listeners.Add(new Log4netTraceListener());
            log4net.Config.XmlConfigurator.Configure();


            

            string zipPath = @"C:\tmp\SP004_RECON_180701.xml.Z";
            string extractPath = @"C:\tmp\!.xml";
            //ZipFile.ExtractToDirectory(zipPath, extractPath);


            //ZlibStream ioz = new ZlibStream(File.OpenRead(zipPath), Ionic.Zlib.CompressionMode.Decompress);

            //var zip1 = new ICSharpCode.SharpZipLib.Zip.ZipInputStream(File.OpenRead(zipPath));
            //var zip = new ICSharpCode.SharpZipLib.GZip.GZipInputStream(File.OpenRead(zipPath));

            #region USING ICSharpCode.SharpZipLib.Lzw
            //using (FileStream fileToDecompressAsStream = File.OpenRead(zipPath))
            //{
            //    string decompressedFileName = extractPath;
            //    using (var decompressionStream = new ICSharpCode.SharpZipLib.Lzw.LzwInputStream(fileToDecompressAsStream))
            //    {
            //        using (FileStream decompressedStream = File.Create(decompressedFileName))
            //        {
            //            try
            //            {
            //                decompressionStream.CopyTo(decompressedStream);
            //            }
            //            catch (Exception ex)
            //            {
            //                Console.WriteLine(ex.Message);
            //            }
            //        }
            //    }
            //}
            #endregion




            //var filestream = new FileStream(zipPath, FileMode.Open, FileAccess.Read);


            //using (var input = new System.IO.FileStream(zipPath, FileMode.Open))
            //{
            //    var decoder = new LzmaDecodeStream(input);
            //    using (var output = new FileStream(extractPath, FileMode.Create))
            //    {
            //        int bufSize = 1024*1024*64, count;
            //        byte[] buf = new byte[bufSize];
            //        while ((count = decoder.Read(buf, 0, bufSize)) > 0)
            //        {
            //            output.Write(buf, 0, count);
            //        }
            //    }
            //}

            //LzmaDecodeStream z7 = new LzmaDecodeStream(File.OpenRead(zipPath));
            //var rdr7 = new StreamReader(z7);
            //while (!rdr7.EndOfStream)
            //{
            //    var s = rdr7.ReadLine();
            //}

            //StreamReader reader = new StreamReader(ioz);
            //while (!reader.EndOfStream)
            //{
            //    var s = reader.ReadLine();
            //}





            //using (var fs = new FileStream(@"C:\tmp\SRCOMBINEDSP20180804163233.0.xml", FileMode.Open))
            //{
            //    XmlReaderSettings xs2 = new XmlReaderSettings();
            //    xs2.IgnoreWhitespace = true;
            //    using (XmlReader reader2 = XmlReader.Create(fs, xs2))
            //    {
            //        try
            //        {
            //            var nt = reader2.MoveToContent();
            //            while (reader2.Read())
            //            {
            //                XmlNodeType nodeType = reader2.NodeType;
            //                if (nodeType == XmlNodeType.Element)
            //                {

            //                }
            //            }

            //        }
            //        catch (Exception ex)
            //        {
            //            Debug.WriteLine(ex.Message);
            //        }
            //    }
            //}
            //sw.Stop();
            //Debug.WriteLine("XML extarcted successfully in {0} ms", sw.ElapsedMilliseconds);



            var lst1 = new List<WifiNetworkDto>
            {
                new WifiNetworkDto
                {
                    Bssid = "11:22:33:44:55:66",
                    Name = "UnityMedia",
                    Password="qwerty",
                    WifiType = "ESSIP"
                },
                new WifiNetworkDto
                {
                    Bssid = "00:00:33:44:55:EE",
                    Name = "TP-LINK",
                    WifiType = "WPA2"
                },
                new WifiNetworkDto
                {
                    Bssid = "AA:BB:CC:44:55:DD",
                    Name = "UnityMedia",
                    Password = "azerty",
                    WifiType = "WEP"
                }
            };

            TheVM = new MainWindowVM(lst1);
            AppendCSV(TheVM);
            TheVM.SortList();

            this.DataContext = TheVM;

            Resources["searchBarStyle"] = Resources["blueSearchBarStyle"];

            InitializeComponent();
        }

        void SaveToCSV(MainWindowVM vm)
        {
            using (var fs = new FileStream(@"c:\tmp\Networks.csv", FileMode.Create))
            {
                using (var fw = new StreamWriter(fs))
                {
                    fw.WriteLine("Name;Bssid;Password;IsBanned;WifiType");
                    foreach(var nw in vm.AllRecords)
                    {
                        var isBanned = nw.IsBanned ? 1 : 0;
                        fw.WriteLine($"{nw.Name};{nw.Bssid};{nw.Password};{isBanned};{nw.WifiType}");
                    }
                }
            }
        }

        void AppendCSV(MainWindowVM vm)
        {
            var csvFN = @"c:\tmp\Networks.csv";
            if (!File.Exists(csvFN))
                return;
            using (var fs = new FileStream(csvFN, FileMode.Open))
            {
                using (var fr = new StreamReader(fs))
                {
                    fr.ReadLine();
                    while(!fr.EndOfStream)
                    {
                        var s = fr.ReadLine();
                        var arrs = s.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                        var nw = new WifiNetworkDto
                        {
                            Bssid=arrs[1].ToUpper(),
                            Name = arrs[0],
                            Password = arrs[2],
                            IsBanned = Convert.ToBoolean( arrs[3]),
                            WifiType = arrs[4]
                        };
                        var detected = vm.AllRecordsQuickSearch[nw.Bssid] != null;
                        nw.IsInCSVList = detected;
                        vm.AllRecords.Add(nw);
                    }
                }
            }
        }

        public class NetezzaImportParameter
        {
            public char FieldDelimiter = '|';//'\xB5';//(char)181; //µ
            public string DateStyle = "DMY";
            public string DateDelimiter = ".";
            public int MaxErrors = 1;
            public string LogDir = @"C:\Log";
            public string BoolStyle = "TRUE_FALSE";
            public string DecimalDelim = System.Globalization.CultureInfo.CurrentUICulture.NumberFormat.NumberDecimalSeparator;
            public string Encoding = "internal";
            public string RemoteSource = "ODBC";
            public string TruncString = "False";

            public override string ToString()
            {
                return String.Format(@"delim '{0}' dateStyle '{1}' datedelim '{2}' boolStyle '{3}' decimalDelim '{4}' maxErrors {5} encoding '{6}' remoteSource '{7}' logDir '{8}' TruncString '{9}'",
                        FieldDelimiter, DateStyle, DateDelimiter, BoolStyle, DecimalDelim, MaxErrors, Encoding, RemoteSource, LogDir, TruncString);
            }

        }


        private int LoadTempTableFromTempFile(OdbcConnection cnnNetezza, string sourceFile, string targetTable, NetezzaImportParameter importSetting)
        {
            File.Delete(System.IO.Path.Combine(importSetting.LogDir, targetTable + ".dwh_db.nzbad"));
            File.Delete(System.IO.Path.Combine(importSetting.LogDir, targetTable + ".dwh_db.nzlog"));

            using (var dbCommandSet = cnnNetezza.CreateCommand())
            {
                dbCommandSet.CommandText = String.Format(@"INSERT INTO {0} SELECT * FROM EXTERNAL '{1}'
                    USING ( DELIM '{2}' datestyle 'DMY' datedelim '.' maxerrors {5} REMOTESOURCE 'ODBC' logDir '{6}')",
                    targetTable, sourceFile, importSetting.FieldDelimiter, importSetting.DateStyle, importSetting.DateDelimiter, importSetting.MaxErrors, importSetting.LogDir);

                return dbCommandSet.ExecuteNonQuery();
            }
        }

        SFTPConnection GetSFTPConnection()
        {
            string host = ConfigurationManager.AppSettings["SFTPHost"];
            string userName = ConfigurationManager.AppSettings["SFTPUserName"];
            string passWord = ConfigurationManager.AppSettings["SFTPPassword"];
            string keyFileFullPath = ConfigurationManager.AppSettings["SFTPPrivateKeyFileUri"];

            var conn = new SFTPConnection(host, userName, passWord, keyFileFullPath);

            return conn;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            DoXmlProcessing(@"C:\tmp\SRCOMBINEDSP20180804163233.0.xml", @"c:\tmp\O2TemplateSR5.xsl", @"C:\tmp\!.tmp", "SI_BEL");
        }

        private static void DoXmlProcessing(string xmlFileName,string xsltFileName, string outputFileName, string theNodeName)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            var TempXml = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(xsltFileName), "temp.xml");
            var TempXslt = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(xsltFileName), System.IO.Path.GetRandomFileName());
            try
            {
                using (var output = new FileStream(TempXml, FileMode.Create))
                {
                    using (var fw1 = new StreamWriter(output))
                    {
                        fw1.WriteLine("<file>" + System.IO.Path.GetFileName(xmlFileName) + "</file>");
                    }
                }

                int count = 0;
                var enc = Encoding.GetEncoding("ISO-8859-1");

                using (XmlReader reader = XmlReader.Create(xmlFileName))
                {
                    using (Stream outputFile = File.Open(outputFileName, FileMode.Create))
                    {
                        using (StreamWriter resultFile = new StreamWriter(outputFile, enc))
                        {
                            XsltSettings settings = new XsltSettings(true, false);

                            XslCompiledTransform xslt = new XslCompiledTransform();

                            xslt.Load(xsltFileName, settings, new XmlUrlResolver());

                            while (reader.ReadToFollowing(theNodeName))
                            {
                                count++;
                                try
                                {
                                    string xmlDoc = reader.ReadOuterXml();

                                    //XElement root = XElement.Parse(xmlDoc);

                                    using (StringReader sri = new StringReader(xmlDoc)) // xmlInput is a string that contains xml
                                    {
                                        using (XmlReader xri = XmlReader.Create(sri))
                                        {
                                            using (StringWriter sw2 = new StringWriter())
                                            {
                                                using (XmlWriter xwo = XmlWriter.Create(sw2, xslt.OutputSettings))
                                                {
                                                    xslt.Transform(xri, xwo);
                                                    var s = sw2.ToString();
                                                    if (string.IsNullOrWhiteSpace(s))
                                                        continue;
                                                    var sb = new StringBuilder(s);
                                                    s = sb.Replace("\xB5", "|").ToString();
                                                    //var firstEOLpos = output.IndexOf("\r\n");
                                                    //output = output.Substring(firstEOLpos + 2);
                                                    //if (string.IsNullOrWhiteSpace(output))
                                                    //    continue;
                                                    //var q1 = output.EndsWith("\r\n\r\n");
                                                    resultFile.Write(s);
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Trace.WriteLine(ex.Message);
                                }
                            }
                        }
                    }
                }
            }
            finally
            {
                File.Delete(TempXml);
            }

            sw.Stop();
            var elapsedMs = sw.ElapsedMilliseconds;
            Debug.WriteLine("XML -> TXT conversion successfully in {0}s", elapsedMs/1000);
        }

        private void ListView_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Resources["searchBarStyle"] = Resources["greenSearchBarStyle"];
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            ToNetezza(@"C:\tmp\!.tmp");
        }

        private int ToNetezza(string importFileName)
        {
            var sqlTblCreate1 = File.ReadAllText(@"C:\tmp\o2_sr_combine_columns_new");
            var tmpTableName = $"TMP_COMBINE_{DateTime.UtcNow.Ticks}";
            sqlTblCreate1 = sqlTblCreate1.Replace("TMP_COMBINE", tmpTableName);

            using (var cnn = new OdbcConnection(ConfigurationManager.ConnectionStrings["NetezzaConnectionString"].ConnectionString))
            {
                cnn.Open();

                try
                {
                    using (var cmd1 = cnn.CreateCommand())
                    {
                        cmd1.CommandTimeout = 240;
                        cmd1.CommandText = sqlTblCreate1;
                        cmd1.ExecuteNonQuery();
                    }

                    var par = new NetezzaImportParameter()
                    ;
                    var cnt1 = LoadTempTableFromTempFile(cnn, @"C:\tmp\O2XMLBulkLoader\SRCOMBINEDSP20180804145802.3.txt", tmpTableName, par);

                    ulong countAlreadyImported;

                    using (var cmd1 = cnn.CreateCommand())
                    {
                        var xmlFileName = System.IO. Path.GetFileName(@"C:\tmp\O2XMLBulkLoader\SRCOMBINEDSP20180804145802.3.xml");
                        cmd1.CommandTimeout = 240;
                        cmd1.CommandText = $@"select count(*)  from O2_SR_COMBINE
                                                where doc_name='{xmlFileName}'";
                        countAlreadyImported = Convert.ToUInt64(cmd1.ExecuteScalar());
                        if (countAlreadyImported > 0)
                        {
                            Trace.TraceInformation($"O2_SR_COMBINE already has {countAlreadyImported} records from {xmlFileName} added earlier.");
                        }
                    }


                    return cnt1;
                }
                catch (Exception ex)
                {
                    Trace.TraceError(ex.Message);

                    return 0;
                }
                finally
                {
                    using (var cmd2 = cnn.CreateCommand())
                    {
                        var sqlTblDrop1 = "DROP TABLE " + tmpTableName;
                        cmd2.CommandText = sqlTblDrop1;
                        cmd2.ExecuteNonQuery();
                    }
                }
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            DoXmlProcessing(@"C:\tmp\SRCOMBINEDSP20180804163233.0.xml", @"c:\tmp\O2TemplateSR5.xsl", @"C:\tmp\!.tmp", "Subscription");
        }


        void ExtrGZ(FileFromSFTP rec)
        {
            string zipPath = rec.DownloadedAs;
            var n1= rec.DownloadedAs.ToUpper().LastIndexOf(".GZ");
            string extractedXmlFileName = rec.DownloadedAs.Substring(0, n1); // @"C:\tmp\SRCOMBINEDSP20180804145802.4.xml";
            int bufSize = 1024 * 128, bytesRead, readCount = 0;
            byte[] buf = new byte[bufSize];

            try
            {
                using (var input = new System.IO.FileStream(zipPath, FileMode.Open))
                {
                    var decoder = new ICSharpCode.SharpZipLib.GZip.GZipInputStream(input);
                    using (var output = new FileStream(extractedXmlFileName, FileMode.Create))
                    {
                        while ((bytesRead = decoder.Read(buf, 0, bufSize)) > 0)
                        {
                            output.Write(buf, 0, bytesRead);
                        }
                    }
                }
                rec.ExtractedXmlFileName = extractedXmlFileName;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        void ExtrZ()
        {
            string zipPath = @"C:\tmp\SP006_RECON_180601.xml.Z";
            string extractPath = @"C:\tmp\SP006_RECON_180601.xml";
            int bufSize = 1024 * 128, bytesRead, readCount = 0;
            byte[] buf = new byte[bufSize];
            bool isFirstLine = true;
            var enc = Encoding.GetEncoding("ISO-8859-1");

            #region USING ICSharpCode.SharpZipLib.Lzw (BUFFERED)
            using (FileStream fileToDecompressAsStream = File.OpenRead(zipPath))
            {
                string decompressedFileName = extractPath;
                using (FileStream decompressedStream = File.Create(decompressedFileName))
                {
                    using (var decompressionStream = new ICSharpCode.SharpZipLib.Lzw.LzwInputStream(fileToDecompressAsStream))
                    {
                        try
                        {
                            while (decompressionStream.CanRead)
                            {
                                while ((bytesRead = decompressionStream.Read(buf, 0, bufSize)) > 0)
                                {
                                    var s = enc.GetString(buf, 0, bytesRead);
                                    var sb = new StringBuilder(s);

                                    sb = sb.Replace("\r", "").Replace("\n", "");
                                    if (isFirstLine)
                                    {
                                        sb = sb.LTrim();
                                        isFirstLine = false;
                                    }

                                    var buf2 = enc.GetBytes(sb.ToString());
                                    decompressedStream.Write(buf2, 0, buf2.Length);
                                    readCount++;
                                    //Trace.WriteLine("Read lines: "+ readCount);
                                    //sb.Clear();
                                    //decompressedStream.Flush();
                                    //GC.Collect();
                                }
                                if (bytesRead == 0)
                                {
                                    break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine(ex.Message);
                        }
                    }
                }
            }
            #endregion
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Trace.WriteLine("Start ");

            ExtrZ();

            Trace.WriteLine("End ");
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            Trace.WriteLine("Start downloading");

            List<FileFromSFTP> downloadedFiles;
            using (var conn = GetSFTPConnection())
            {
                downloadedFiles = GetSFTPFilesAndConnection(conn);
                DownloadFilesFromSftp(conn, downloadedFiles);
            }
            Trace.WriteLine("End downloading");

            Trace.WriteLine("Start processing");
            ProcessFiles(downloadedFiles);
            Trace.WriteLine("End processing");
        }

        private void DownloadFilesFromSftp(SFTPConnection conn, List<FileFromSFTP> downloadedFiles)
        {
            foreach (var rec in downloadedFiles)
            {
                DownloadFile(conn, rec);
                //string zipPath = @"C:\tmp\SRCOMBINEDSP20180804145802.4.xml.gz";
                //string extractPath = @"C:\tmp\SRCOMBINEDSP20180804145802.4.xml";
            }
        }

        private List<FileFromSFTP> GetSFTPFilesAndConnection(SFTPConnection conn)
        {
            var fullUnixInputDir = ConfigurationManager.AppSettings["SourceDataPath"];
            var qq = conn.ListDirectory(fullUnixInputDir);
            var fntoBeRead = qq.Where(r => r.Name.ToUpper().Contains("COMB") && r.Name.ToUpper().EndsWith(".XML.GZ"))
.Take(1)
                .Select(r => new FileFromSFTP
            {
                FileOnSFTP = r,
                DownloadedAs = r.Name
            }
            );
            var downloadedFiles = new List<FileFromSFTP>(fntoBeRead);
            return downloadedFiles;
            //var fullUnixUri = @"/appia/net_files/o2/pro/SRCOMBINEDSP20180804145802.0.xml";
            //conn.GetFile(fullUnixUri, @"C:\tmp\!!!-SHORT.xml");
        }

        private void ProcessFiles(List<FileFromSFTP> downloadedFiles)
        {
            var TempDir = ConfigurationManager.AppSettings["TempDir"];
            var XsltFileName = ConfigurationManager.AppSettings["XsltFileName"];
            //var downloadedFilesLocal = Directory.GetFiles(TempDir , "*.GZ");

            Parallel.ForEach(downloadedFiles, (rec) => {
                Trace.WriteLine($"Start processing {rec.DownloadedAs}");
                ExtrGZ(rec);
                rec.XsltOutputName = System.IO.Path.Combine(TempDir, System.IO.Path.GetFileNameWithoutExtension(rec.ExtractedXmlFileName) + ".txt");
                DoXmlProcessing(rec.ExtractedXmlFileName, XsltFileName, rec.XsltOutputName, "SI_BEL");
                var cnt1 = ToNetezza(rec.XsltOutputName);
                rec.Processed = true;
                Trace.WriteLine(string.Format($"End processing {rec.DownloadedAs}. Uploaded {cnt1} records"));
            });
        }

        private void DownloadFile(SFTPConnection conn, FileFromSFTP rec)
        {
            rec.DownloadedAs = System.IO.Path.Combine(ConfigurationManager.AppSettings["TempDir"], rec.FileOnSFTP.Name);
            conn.GetFile(rec.FileOnSFTP.FullName, rec.DownloadedAs);
        }
    }
}
